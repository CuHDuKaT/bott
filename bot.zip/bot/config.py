TOKEN = '5941764415:AAEkGZQaShVK-t1YvCBTDlxmXh9AAR0X-KE' #Токен бота
admin = 5508708893
db = 'db.db'